<?php
header("location:adminlogin.php");
?>