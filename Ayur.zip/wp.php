<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook Account</title>
    <style>
        *{
            font-family: 'Roboto', sans-serif;
        }
         .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
            padding: 20px 0;
        }
    </style>
</head>
<body>
    <?php
    include("header.php");
    ?>
<br><br>
<center>
    <h3>Our Whatsapp account</h3>
</center>
<div class="container">
        <img src="././images/wp.jpg" alt="Facebook" srcset="">
    </div>
</body>
<?php
include("footer.php");
?>
</html>